export interface SignupRequestPayload {
    username: string;
    password: string;
    email: string;
    prnnumber: number;
    firstname: String;
    lastname:string;
    course:string;
}
